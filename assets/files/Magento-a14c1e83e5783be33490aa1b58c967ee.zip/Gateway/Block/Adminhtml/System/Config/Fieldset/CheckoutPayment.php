<?php

namespace WPG\Gateway\Block\Adminhtml\System\Config\Fieldset;

/**
 * Renderer for Wpg Checkout Panel in System Configuration
 *
 * Class CheckoutPayment
 * @package WPG\Gateway\Block\Adminhtml\System\Config\Fieldset
 */
class CheckoutPayment extends \WPG\Gateway\Block\Adminhtml\System\Config\Fieldset\Base\Payment
{
    /**
     * Retrieves the Module Panel Css Class
     * @return string
     */
    protected function getBlockHeadCssClass()
    {
        return "WpgCheckout";
    }
}
