
define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';

        rendererList.push(
            {
                type: 'wpg_checkout',
                component: 'WPG_Gateway/js/view/payment/method-renderer/checkout-method'
            }//,
            // {
            //     type: 'wpg_direct',
            //     component: 'WPG_Gateway/js/view/payment/method-renderer/direct-method'
            // }
        );

        /** Add view logic here if needed */
        return Component.extend({});
    }
);
