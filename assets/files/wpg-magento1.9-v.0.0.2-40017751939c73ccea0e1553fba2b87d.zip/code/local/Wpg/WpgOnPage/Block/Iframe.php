<?php

class Wpg_WpgOnPage_Block_Iframe extends Mage_Payment_Block_Form
{
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('wpg/iframe.phtml');
    }

    protected function _toHtml()
    {
        return parent::_toHtml();
    }
}
