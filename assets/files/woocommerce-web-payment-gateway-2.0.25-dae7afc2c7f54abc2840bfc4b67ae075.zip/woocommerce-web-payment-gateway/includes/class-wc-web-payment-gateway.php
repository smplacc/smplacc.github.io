<?php

use function Barn2\Plugin\WC_Product_Options\Dependencies\retry;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Web_Payment_Gateway class.
 *
 * @since 2.0.0
 * @extends WC_Payment_Gateway
 */
class WC_Web_Payment_Gateway extends WC_Payment_Gateway
{

    protected $apimethod = array(
        'checkout' => '/api/v1/session',
        'refund'   => '/api/v1/payment/refund'
    );

    public $url;
    public $method;
    public $secret;
    public $password;
    public $display_icon;
    public $vat_calculation;
    public $iframe;
    public $form_id;
    public $url_target;
    public $preferred_iframe_hook;
    public $order_status_after_payment;

    public $debug = 'no';


    public $currencies_3dotexponent = ['BHD', 'JOD', 'KWD', 'OMR', 'TND'];
    public $currencies_noexponent = [
        //'CLP', 
        'VND',
        'ISK',
        'UGX',
        //'KRW', 
        //'JPY'
    ];

    /**
     * Constructor
     */
    public function __construct()
    {
        global $woocommerce;
        
        // Register plugin information
        $this->id = 'wpgfull';
        $this->has_fields = true;
        $this->supports = array(
            'refunds',
            'products',
        );

        // Create plugin fields and settings
        $this->init_form_fields();
        $this->init_settings();

        // Get setting values
        foreach ($this->settings as $key => $val) {
            $this->$key = $val;
        }


        if (empty($this->icon)) {
            // Load plugin checkout default icon
            $this->icon = WC_WPG_PLUGIN_URL . '/images/default-logo.png';
        }


        if ($this->display_icon == 'yes') {
            $this->icon = false;
        }

        //image select
        add_action('admin_enqueue_scripts', array($this, 'loadscripts'));
        add_action('woocommerce_api_wc_set_picture', array($this, 'get_new_image'));


        // Add hooks
        // add_action('woocommerce_thankyou_wpgfull', array($this, 'receipt_page'), 10, 1);
        // add_action('woocommerce_order_details_after_customer_details', array($this, 'receipt_page'), 10, 1);

        add_action($this->preferred_iframe_hook, array($this, 'receipt_page'), 10, 1);

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

        add_action('admin_notices', array($this, 'wpgfull_commerce_ssl_check'));

        // Payment listener/API hook
        add_action('woocommerce_api_wc_web_payment_gateway', array($this, 'check_ipn_response'));

        add_filter('woocommerce_shared_settings', [$this, 'modifyCheckoutFieldsNewHook'], 30);
        add_filter('the_content',  [$this, 'editCheckoutContent']);
    }


    public function get_new_image()
    {
        if (isset($_GET['id'])) {
            $data = array(
                'image'    => wp_get_attachment_image(filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT), array(90, 20), false, array('id' => 'wpg_custom_logo_prewiev')),
                'imageurl' => wp_get_attachment_image_url(filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT), array(90, 20), true),
            );
            wp_send_json_success($data);
        } else {
            wp_send_json_error();
        }
    }

    function loadscripts($page)
    {
        if ($page == 'woocommerce_page_wc-settings') {
            wp_enqueue_media();
            wp_enqueue_script('wpg_load_logo', WC_WPG_PLUGIN_DIR . 'js/wpg_load_logo.js', array('jquery'));
        }
    }


    /**
     * Refund function for gateway if suppors
     **/

    public function process_refund($order_id, $amount = null, $reason = '')
    {
        $order = wc_get_order($order_id);
        if (!is_a($order, \WC_Order::class)) {
            return false;
        }

        $correct_amount = number_format($amount, 2, '.', '');
        if (in_array(get_woocommerce_currency(), $this->currencies_noexponent)) {
            $correct_amount = number_format($order->get_total(), 0, '.', '');
        } elseif (in_array(get_woocommerce_currency(), $this->currencies_3dotexponent)) {
            $correct_amount = number_format($order->get_total(), 3, '.', '');
        }


        $transaction_id = $order->get_transaction_id();
        $hash = sha1(md5(strtoupper($transaction_id . $correct_amount . $this->password)));
        $main_json = array(
            'merchant_key' => $this->secret,
            'payment_id'    => $transaction_id,
            'amount'      => $correct_amount,
            'hash'         => $hash
        );

        $action_adr = rtrim($this->url, '/') . $this->apimethod['refund'];

        $response = $this->makeRequest($action_adr, $main_json);

        if ($response === false) {
            return false;
        }

        if ($response['result'] == 'accepted' && $response['payment_id'] == $transaction_id) {
            return true;
        }

        return false;
    }

    public function check_ipn_response()
    {
        global $woocommerce;

        $this->log('POST api: ' . print_r($_POST, true));
        $this->log('wpgLog', 'GET api: ' . print_r($_GET, true));

        if ($_SERVER['REQUEST_METHOD'] != 'POST') {
            exit;
        }

        $hash_string = $_POST['id'] . $_POST['order_number'] . $_POST['order_amount'] . $_POST['order_currency'] . $_POST['order_description'] . $this->password;
        $hash = sha1(md5(strtoupper($hash_string)));

        if ($_POST['hash'] != $hash) {
            //error_log("hash invalid");
            exit;
        }

        $order_id = $_POST['order_number'];

        $order = wc_get_order($order_id);


        $order->set_transaction_id($_POST['id']);

        if ($order->get_status() == 'pending' || $order->get_status() == 'waiting' || $order->get_status() == 'failed' || $order->get_status() == '') {

            if ($_POST['status'] == 'success' && $_POST['type'] == 'sale') {
                //successful purchase
                $woocommerce->cart->empty_cart();
                $order->update_status($this->order_status_after_payment, 'Payment successfully paid'); //completed or processing
                //$order->payment_complete($_POST['id']);

                if (isset($_POST['vat_amount'])) {
                    $order->add_meta_data('wpg_vat_amount', $_POST['vat_amount']);
                    $order->save();
                }

                exit;
            }

            if ($_POST['status'] == 'waiting' && $_POST['type'] == 'sale') {
                //waiting purchase
                $order->update_status('on-hold', __('On hold', 'woocommerce'));
                exit;
            }

            if ($_POST['status'] == 'fail' && $_POST['type'] == 'sale') {
                //failed purchase
                $order->update_status('failed', $_POST['reason']);
                exit;
            }
        }

        if ($order->get_status() == 'completed' || $order->get_status() == 'processing') {
            if ($_POST['status'] == 'success' && $_POST['type'] == 'refund') {
                //$order->update_status('refunded', __('Refunded', 'woocommerce'));
                $order->add_order_note('Refund confirmed by the payment system');
                exit;
            }
            if ($_POST['status'] == 'fail' && $_POST['type'] == 'refund') {
                $order->update_status('failed', $_POST['reason']);
                exit;
            }
        }
    }


    /**
     * Check if SSL is enabled and notify the user.
     */
    function wpgfull_commerce_ssl_check()
    {
        //if (!$_POST)
        //if ('no' == get_option('woocommerce_force_ssl_checkout') && 'yes' == $this->enabled) {
        if (is_ssl() == false && 'yes' == $this->enabled) {
            $admin_url = admin_url('admin.php?page=wc-settings&tab=checkout');
            echo '<div class="notice notice-error is-dismissible"><p>' . sprintf(__('WPG is enabled. But <a href="%s">force SSL option</a> is disabled. Your checkout is not secure! Please enable SSL and ensure your server has a valid SSL certificate.', 'woocommerce-gateway-wpgfull'), $admin_url) . '</p></div>';
        }
    }

    /**
     * Initialize Gateway Settings Form Fields.
     */
    function init_form_fields()
    {
        $orderStatuses = wc_get_order_statuses();

        unset($orderStatuses['wc-pending']);
        unset($orderStatuses['wc-on-hold']);
        unset($orderStatuses['wc-cancelled']);
        unset($orderStatuses['wc-refunded']);
        unset($orderStatuses['wc-failed']);
        unset($orderStatuses['wc-checkout-draft']);

        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable/Disable', 'woocommerce-gateway-wpgfull'),
                'label' => __('Enable WPG Commerce', 'woocommerce-gateway-wpgfull'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
            ),
            'title' => array(
                'title' => __('Title', 'woocommerce-gateway-wpgfull'),
                'type' => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'woocommerce-gateway-wpgfull'),
                'default' => __('WPG Commerce', 'woocommerce-gateway-wpgfull'),
                'desc_tip' => true,
            ),
            'description' => array(
                'title' => __('Front description', 'woocommerce-gateway-wpgfull'),
                'type' => 'text',
                'default' => __('Pay online through WPG Commerce', 'woocommerce-gateway-wpgfull'),
            ),
            'method_description' => array(
                'title' => __('Description', 'woocommerce-gateway-wpgfull'),
                'type' => 'textarea',
                'description' => __('WPG redirects customers enter payment details.', 'woocommerce-gateway-wpgfull'),
                'default' => __('You can make a payment through the Web Payment Gateway system', 'woocommerce'),
            ),
            'url' => array(
                'title' => __('Checkout host', 'woocommerce-gateway-wpgfull'),
                'type' => 'text',
                'description' => __('Url from payment system to send a payment request', 'woocommerce-gateway-wpgfull'),
            ),
            'method' => array(
                'title' => __('Payment method', 'woocommerce-gateway-wpgfull'),
                'type' => 'multiselect',
                'description' => __('Payment method that client uses', 'woocommerce-gateway-wpgfull'), /////
                'options' => array(
                    'card' => 'Card',
                    'googlepay' => 'Google Pay',
                    'paypal' => 'Pay Pal',
                ),
            ),
            'secret' => array(
                'title' => __('Merchant key', 'woocommerce-gateway-wpgfull'),
                'type' => 'text',
                'description' => __('Merchant key from payment system for customer identification', 'woocommerce-gateway-wpgfull'),
            ),
            'password' => array(
                'title' => __('Merchant password', 'woocommerce-gateway-wpgfull'),
                'type' => 'text',
                'description' => __('Merchant password from payment system.', 'woocommerce-gateway-wpgfull'),
            ),

            'vat_calculation' => array(
                'title' => __('VAT Calculation', 'woocommerce-gateway-wpgfull'),
                'label' => __('Enable/Disable', 'woocommerce-gateway-wpgfull'),
                'type' => 'checkbox',
                'description' => __('The tax is calculated by the payment system. The order amount is passed tax-free, regardless of Woocommerce Tax settings.', 'woocommerce-gateway-wpgfull'),
                'default' => 'no',
            ),

            'iframe' => array(
                'title' => __('Iframe payment', 'woocommerce-gateway-wpgfull'),
                'label' => __('Enable/Disable', 'woocommerce-gateway-wpgfull'),
                'type' => 'checkbox',
                'description' => __('Show payment form in iframe after checkout.', 'woocommerce-gateway-wpgfull'),
                'default' => 'no',
            ),

            'url_target' => array(
                'title' => __('Url target', 'woocommerce-gateway-wpgfull'),
                'type' => 'select',
                'description' => __('A browsing context where Customer should be returned', 'woocommerce-gateway-wpgfull'),
                'options' => array(
                    'noused' => 'Not used',
                    'self' => 'Self',
                    'blank' => 'Blank',
                    'parent' => 'Parent',
                    'top' => 'Top',
                ),
                'default' => 'noused',
            ),

            'preferred_iframe_hook' => array(
                'title' => __('Display hook', 'woocommerce-gateway-wpgfull'),
                'type' => 'select',
                'description' => __('Selection of the hook on which to show the iframe'),
                'options' => array(
                    'woocommerce_thankyou_wpgfull' => 'woocommerce_thankyou',
                    'woocommerce_order_details_after_customer_details' => 'woocommerce_order_details_after_customer_details',
                ),
                'default' => 'woocommerce_thankyou_wpgfull',
            ),

            'form_id' => array(
                'title' => __('Form id', 'woocommerce-gateway-wpgfull'),
                'type' => 'text',
                'description' => __('Id form to show your own design, approved by the manager.', 'woocommerce-gateway-wpgfull'),
            ),

            'order_status_after_payment' => array(
                'title' => __('Order status', 'woocommerce-gateway-wpgfull'),
                'type' => 'select',
                'description' => __('Select the order status that will be set after successful payment', 'woocommerce-gateway-wpgfull'),
                'options' => $orderStatuses,
                'default' => 'wc-completed',
            ),

            'debug' => array(
                'title' => __('Enable debug', 'woocommerce-gateway-wpgfull'),
                'type' => 'text',
                'default' => 'no',
                'description' => __('Enable debug logs', 'woocommerce-gateway-wpgfull'),
            ),
            'display_icon' => array(
                'title' => __('Hide icon on front', 'woocommerce-gateway-wpgfull'),
                'type' => 'checkbox'
            ),
            'icon' => array(
                'type' => 'hidden',
                'class' => 'wpg_custom_logo',
            ),
        );
    }

    /**
     * UI - Admin Panel Options
     */
    function admin_options()
    {

?>
        <h3><?php _e('Web Payment Gateway Settings', 'woocommerce-gateway-wpgfull'); ?></h3>
        <p><?php _e('Web Payment Gateway. The plugin works by opened checkout page, and then sending the details to payment system for verification.', 'woocommerce-gateway-wpgfull'); ?></p>
        <input type="hidden" name="" id="wc_api_url" value="<?php echo add_query_arg('wc-api', 'wc_set_picture', home_url('/')); ?>">
        <table class="form-table">
            <?php
            $this->generate_settings_html();
            ?>
            <p>
                <strong><?php _e('Callback Url: ') ?></strong><?php echo add_query_arg('wc-api', 'wc_web_payment_gateway', home_url('/')); ?>
            </p>
            <!--  -->
            <tr valign="top" class="">
                <th scope="row" class="titledesc">
                    <label for="myprefix_media_manager">Logo </label>
                </th>
                <td class="forminp">
                    <fieldset>
                        <legend class="screen-reader-text"><span>Preview</span></legend>
                        <img id="wpg_custom_logo_prewiev" width="90" height="20" src="<?= $this->icon ?>" alt="<?= $this->title ?>">
                        <input type='button' class="button-primary" value="<?php esc_attr_e('Select a image', 'mytextdomain'); ?>" id="myprefix_media_manager" />
                        <p class="description">Custom logo payment system.</p>
                    </fieldset>
                </td>
            </tr>
            <!--  -->
        </table>


    <?php
    }


    /**
     * Process the payment and return the result.
     *
     * @param int @order_id
     * @return array
     */
    public function process_payment($order_id)
    {

        $order = new WC_Order($order_id);
    
        if ($this->iframe == 'yes') {
            return array(
                'result' => 'success',
                'redirect' => $this->get_return_url($order),
            );
        } else {
            return array(
                'result' => 'success',
                'redirect' => $this->get_transaction_url($order)
            );
        }
    }


    /**
     * Display information on the Thank You page
     *
     * @param $order
     */
    public function receipt_page($order_or_id)
    {

        if ($order_or_id instanceof WC_Order) {
            $order = $order_or_id;
        }else{
            $order = new WC_Order($order_or_id);
        }
 

        if (!$order->is_paid() && !$this->checkIfIframeShowed($order)) {
            $url = $this->get_transaction_url($order);

            WC()->session->set('wpg_showed_' . $order->get_id(), '1');

            $this->getFrame($url);
        }
    }

    protected function getFrame($url)
    {
        if (empty($url)) {
            return;
        }

        ?>

            <iframe id="paymentFrame" src="<?php echo $url ?>" frameborder="0" style="width: 100%; height:1200px"></iframe>


            <script>
                // const paymentFrame = document.getElementById('paymentFrame');
                // paymentFrame.addEventListener('load', (ev) => {

                //     try {
                //         let link = paymentFrame.contentWindow.location.href;
                //         if (link.includes(window.location.host)) {
                //             paymentFrame.style.display = 'none';
                //             window.location.href = link;
                //         }
                //     } catch (error) {

                //     }
                // })
            </script>


        <?php
    }

    protected function checkIfIframeShowed($order)
    {
        $key = 'wpg_showed_' . $order->get_id();
        
        if (WC()->session->get($key, false) !== false) {
            return true;
        }

        return false;
    }

    public function generate_form($order_id, bool $returnurl = false)
    {
        global $woocommerce;

        $order = new WC_Order($order_id);

        $action_adr = rtrim($this->url, '/') . $this->apimethod['checkout'];

        $customer = $this->buildCustomer($order);
        $billing_address = $this->buildBillingAddress($order);

        if ($this->settings['vat_calculation'] === 'yes') {

            $orderTotal = $order->get_total();
            $orderTax = $order->get_total_tax();

            $amountTaxFree = $orderTotal - $orderTax;
            $amount = $this->formatPrice($amountTaxFree);
        } else {
            $amount = $this->formatPrice($order->get_total());
        }

        $order_json = array(
            'number' => "$order_id",
            'description' => __('Payment Order # ', 'woocommerce') . $order_id . __(' in the store ', 'woocommerce') . home_url('/'),
            'amount' => $amount,
            'currency' => get_woocommerce_currency(),
        );

      
        $str_to_hash = $order_id . $amount . get_woocommerce_currency() . __('Payment Order # ', 'woocommerce') . $order_id . __(' in the store ', 'woocommerce') . home_url('/') . $this->password;
        $hash = sha1(md5(strtoupper($str_to_hash)));

        $main_json = array(
            'merchant_key' => $this->secret,
            'operation'    => 'purchase',
            'order'        => $order_json,
            'customer'     => $customer,
            'billing_address' => $billing_address,
            'success_url' => $this->get_return_url($order),
            'cancel_url'   => $order->get_view_order_url(),
            'hash'         => $hash,

        );

        $methods = $this->method;
        if (!empty($methods)) {
             $main_json['methods'] = $methods;
        }

        if ($this->settings['vat_calculation'] === 'yes') {
            $main_json['vat_calc'] = true;
        }

        if (!empty($this->settings['form_id'])) {
            $main_json['from_id'] = $this->settings['form_id'];
        }

        if ($this->iframe == 'yes') {
            if ($this->url_target != 'noused') {
                $main_json['url_target'] = '_' . $this->url_target;
            }
        }

        $response = $this->makeRequest($action_adr, $main_json);
        if ($response === false) {
            return false;
        }

        if ($returnurl === true) {
            return $response['redirect_url'];
        }

        return
            '<a class="button alt" href="' . $response['redirect_url'] . '">' . __('Pay', 'woocommerce') . '</a> <a class="button cancel" href="' . $order->get_cancel_order_url() . '">' . __('Refuse payment & return to cart', 'woocommerce') . '</a>' . "\n";
    }

    public function get_transaction_url($order)
    {
        $url = $this->generate_form($order->get_id(), true);
        return $url ? $url : '';
    }

    protected function buildCustomer(WC_Order $order)
    {
        $customer = array(
            'name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            'email' => $order->get_billing_email(),
        );

        return $customer;
    }

    protected function buildBillingAddress(WC_Order $order)
    {

        $stateFullname = 'NA';
        if ($order->get_billing_state()) {
            $states = WC()->countries->get_states($order->get_billing_country());
            $stateFullname = $states[$order->get_billing_state()];
        }
      

        $billing_address = [
            'country' => $order->get_billing_country() ? $order->get_billing_country() : 'NA',
            'state' =>  $stateFullname,
            'city' => $order->get_billing_city() ? $order->get_billing_city() : 'NA',
            'address' => $order->get_billing_address_1() ? $order->get_billing_address_1() : 'NA',
            'zip' => $order->get_billing_postcode() ? $order->get_billing_postcode() : 'NA',
            'phone' => $order->get_billing_phone() ? $order->get_billing_phone() : 'NA',
        ];



        return $billing_address;
    }

    protected function formatPrice($total)
    {
        $amount = number_format($total, 2, '.', '');
        if (in_array(get_woocommerce_currency(), $this->currencies_noexponent)) {
            $amount = number_format($total, 0, '.', '');
        } elseif (in_array(get_woocommerce_currency(), $this->currencies_3dotexponent)) {
            $amount = number_format($total, 3, '.', '');
        }
        return $amount;
    }

    protected function log($message)
    {
        if ('yes' == $this->debug) {
            $log = new WC_Logger();
            $log->add('wpgLog', $message);
        }
    }


    protected function makeRequest($url, $body)
    {
        $getter = curl_init($url); //init curl
        curl_setopt($getter, CURLOPT_POST, 1); //post
        curl_setopt($getter, CURLOPT_POSTFIELDS, json_encode($body)); //json
        curl_setopt($getter, CURLOPT_HTTPHEADER, array('Content-Type:application/json')); //header
        curl_setopt($getter, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($getter);
        $httpcode = curl_getinfo($getter, CURLINFO_HTTP_CODE);

        $this->log('CheckoutGetUrl: ' . $url);
        $this->log('CheckoutGet: ' . json_encode($body));
        $this->log('CheckoutResponse: ' . $httpcode . ' ' . $result);

        if ($httpcode != 200) {
            return false;
        }
        $response = json_decode($result, true);

        return $response;
    }

    //gutenberg checkout
    public function modifyCheckoutFieldsNewHook($fields)
    {

        if (isset($fields['defaultFields']['phone'])) {
            $fields['data-require-phone-field']['phone']['required'] = true;
            $fields['defaultFields']['phone']['hidden'] = false;
        }

        return $fields;
    }

    public function editCheckoutContent($content)
    {

        global $post;

        if ($post->ID == wc_get_page_id('checkout')) {

            if (str_contains($content, 'data-require-phone-field="true"')) {
                return $content;
            } else {

                $content = str_replace(['data-block-name="woocommerce/checkout"', 'data-show-phone-field="false"'], ['data-block-name="woocommerce/checkout" data-require-phone-field="true"', ''], $content);
            }
        }

        return $content;
    }
}
